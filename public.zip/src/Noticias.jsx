import React, { useState, useEffect, useRef } from 'react';

const Noticias = () => {
  const [noticias, setNoticias] = useState([]);
  const [error, setError] = useState(null);
  const [noticiaActual, setNoticiaActual] = useState(0);
  const [estaLeyendo, setEstaLeyendo] = useState(false);
  const [paginaCargada, setPaginaCargada] = useState(false);
  const noticiaRefs = useRef([]);

  // Función para leer texto usando el lector de pantalla
  const leerTexto = (texto, interrumpir = true) => {
    if (interrumpir) {
      speechSynthesis.cancel();
    }
    const utterance = new SpeechSynthesisUtterance(texto);
    utterance.lang = 'es-ES'; // Configurar el idioma a español
    speechSynthesis.speak(utterance);
  };

  // Función para leer el mensaje de bienvenida
  const leerBienvenida = () => {
    const mensajeBienvenida = `
      Bienvenido al lector de noticias. 
      Se han cargado ${noticias.length} noticias.
      Instrucciones de navegación:
      Use las flechas arriba y abajo para moverse entre noticias.
      Presione la barra espaciadora para escuchar la noticia actual.
      Presione Enter para abrir el enlace de la noticia en una nueva ventana.
      Presione la tecla H para escuchar estas instrucciones nuevamente.
      ¿Desea comenzar con la primera noticia? Presione la barra espaciadora para escucharla.
    `;
    leerTexto(mensajeBienvenida);
  };

  useEffect(() => {
    const fetchNoticias = async () => {
      try {
        const url = 'https://newsapi.org/v2/top-headlines?country=us&apiKey=b8b172d440e34e69a222e7cb7037140e';
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.status === 'ok') {
          setNoticias(data.articles);
          setPaginaCargada(true);
        } else {
          setError('No se pudieron cargar las noticias');
          leerTexto('Error al cargar las noticias. Por favor, intente más tarde.');
        }
      } catch (error) {
        setError('Hubo un problema con la solicitud');
        leerTexto('Error al cargar las noticias. Por favor, intente más tarde.');
      }
    };
    fetchNoticias();
  }, []);

  // Efecto para leer el mensaje de bienvenida cuando se cargan las noticias
  useEffect(() => {
    if (paginaCargada && noticias.length > 0) {
      leerBienvenida();
    }
  }, [paginaCargada, noticias.length]);

  // Configurar los event listeners del teclado
  useEffect(() => {
    const handleKeyPress = (e) => {
      switch(e.key) {
        case 'ArrowDown':
          e.preventDefault();
          navegarNoticias('siguiente');
          break;
        case 'ArrowUp':
          e.preventDefault();
          navegarNoticias('anterior');
          break;
        case ' ': // Tecla espacio
          e.preventDefault();
          toggleLectura();
          break;
        case 'Enter':
          e.preventDefault();
          abrirNoticia();
          break;
        case 'h':
        case 'H':
          e.preventDefault();
          leerBienvenida();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [noticiaActual, noticias]);

  const navegarNoticias = (direccion) => {
    setEstaLeyendo(false);
    let nuevaNoticia = noticiaActual;
    
    if (direccion === 'siguiente' && noticiaActual < noticias.length - 1) {
      nuevaNoticia = noticiaActual + 1;
    } else if (direccion === 'anterior' && noticiaActual > 0) {
      nuevaNoticia = noticiaActual - 1;
    }

    setNoticiaActual(nuevaNoticia);
    const mensaje = `Noticia ${nuevaNoticia + 1} de ${noticias.length}. Presione espacio para escucharla.`;
    leerTexto(mensaje);
  };

  useEffect(() => {
    if (noticiaRefs.current[noticiaActual]) {
      noticiaRefs.current[noticiaActual].scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [noticiaActual]);

  const toggleLectura = () => {
    setEstaLeyendo(!estaLeyendo);
    const noticia = noticias[noticiaActual];
    if (!estaLeyendo && noticia) {
      const texto = `${noticia.title}. ${noticia.description || ''}`;
      leerTexto(texto);
    } else {
      speechSynthesis.cancel();
    }
  };

  const abrirNoticia = () => {
    const noticia = noticias[noticiaActual];
    if (noticia && noticia.url) {
      window.open(noticia.url, '_blank');
      leerTexto('Abriendo enlace en una nueva ventana');
    }
  };

  return (
    <div className="noticias-container">
      <h1>Últimas Noticias</h1>
      
      {error && <p className="error" role="alert">{error}</p>}
      
      <div 
        className="instrucciones" 
        role="region" 
        aria-label="Instrucciones de navegación"
        tabIndex="0"
      >
        <p>Use las flechas ↑↓ para navegar entre noticias</p>
        <p>Presione ESPACIO para leer la noticia</p>
        <p>Presione ENTER para abrir el enlace</p>
        <p>Presione H para escuchar las instrucciones</p>
        <p>Total de noticias: {noticias.length}</p>
      </div>

      <div role="alert" aria-live="polite" className="sr-only">
        {noticias.length > 0 && `${noticias.length} noticias cargadas`}
      </div>

      {noticias.length > 0 ? (
        <div role="feed" aria-label="Lista de noticias">
          {noticias.map((article, index) => (
            <div
              key={index}
              ref={el => noticiaRefs.current[index] = el}
              className={`noticia ${index === noticiaActual ? 'noticia-activa' : ''}`}
              role="article"
              aria-selected={index === noticiaActual}
              tabIndex={index === noticiaActual ? 0 : -1}
            >
              {article.urlToImage && (
                <img 
                  src={article.urlToImage} 
                  alt={article.title} 
                  className="noticia-img"
                  onError={(e) => e.target.style.display = 'none'}
                />
              )}
              <h2>{article.title}</h2>
              <p>{article.description}</p>
              <a 
                href={article.url} 
                target="_blank" 
                rel="noopener noreferrer"
                aria-label={`Leer más sobre: ${article.title}`}
              >
                Leer más
              </a>
            </div>
          ))}
        </div>
      ) : (
        <p role="status">Cargando noticias...</p>
      )}
    </div>
  );
};

export default Noticias;