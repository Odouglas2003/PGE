import React, { useState, useEffect, useRef } from 'react';

const Noticias = () => {
  const [noticias, setNoticias] = useState([]);
  const [error, setError] = useState(null);
  const [noticiaActual, setNoticiaActual] = useState(0);
  const [estaLeyendo, setEstaLeyendo] = useState(false);
  const [paginaCargada, setPaginaCargada] = useState(false);
  const noticiaRefs = useRef([]);
  const instruccionesRef = useRef(null);

  // Mejora: Configuración más robusta del lector de voz
  const leerTexto = (texto, interrumpir = true, prioridad = false) => {
    if (interrumpir) {
      speechSynthesis.cancel();
    }

    const utterance = new SpeechSynthesisUtterance(texto);
    utterance.lang = 'es-ES';
    utterance.rate = 1.0; // Velocidad normal
    utterance.pitch = 1.0; // Tono normal
    utterance.volume = 1.0; // Volumen máximo

    // Seleccionar una voz en español si está disponible
    const voces = speechSynthesis.getVoices();
    const vozEspanol = voces.find(voz => voz.lang.startsWith('es'));
    if (vozEspanol) {
      utterance.voice = vozEspanol;
    }

    if (prioridad) {
      speechSynthesis.speak(utterance);
    } else {
      // Esperar a que termine el mensaje actual
      setTimeout(() => speechSynthesis.speak(utterance), 250);
    }

    return utterance;
  };

  // Mejora: Mensaje de bienvenida más completo y estructurado
  const leerBienvenida = () => {
    const mensajeBienvenida = `
      Bienvenido al lector de noticias accesible.
      Se han cargado ${noticias.length} noticias para tu lectura.
      Para ayudarte a navegar, aquí están las instrucciones:
      Usa la flecha hacia arriba para ir a la noticia anterior.
      Usa la flecha hacia abajo para ir a la siguiente noticia.
      Presiona la barra espaciadora para escuchar la noticia actual o detener la lectura.
      Presiona Enter para abrir el enlace de la noticia en una nueva ventana.
      Presiona la tecla H en cualquier momento para escuchar estas instrucciones nuevamente.
      Presiona la tecla M para silenciar todas las lecturas.
      Presiona la tecla R para repetir la última noticia leída.
      Estás en la primera noticia. Presiona la barra espaciadora para comenzar a escucharla.
    `;
    leerTexto(mensajeBienvenida, true, true);
  };

  // Mejora: Manejo más robusto de errores
  useEffect(() => {
    const fetchNoticias = async () => {
      try {
        const url = 'https://newsapi.org/v2/top-headlines?country=us&apiKey=b8b172d440e34e69a222e7cb7037140e';
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.status === 'ok' && data.articles?.length > 0) {
          setNoticias(data.articles);
          setPaginaCargada(true);
        } else {
          const errorMsg = 'No se pudieron cargar las noticias. Por favor, intente más tarde.';
          setError(errorMsg);
          leerTexto(errorMsg, true, true);
        }
      } catch (error) {
        const errorMsg = 'Hubo un problema al conectar con el servidor. Por favor, verifique su conexión a internet.';
        setError(errorMsg);
        leerTexto(errorMsg, true, true);
      }
    };
    
    leerTexto('Cargando noticias, por favor espere...', true, true);
    fetchNoticias();
  }, []);

  // Mejora: Manejar el foco inicial y las instrucciones
  useEffect(() => {
    if (paginaCargada && noticias.length > 0) {
      setTimeout(() => {
        leerBienvenida();
        if (instruccionesRef.current) {
          instruccionesRef.current.focus();
        }
      }, 500);
    }
  }, [paginaCargada, noticias.length]);

  // Mejora: Navegación por teclado más completa
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
        return; // No interceptar teclas si estamos en un campo de entrada
      }

      switch(e.key) {
        case 'ArrowDown':
          e.preventDefault();
          navegarNoticias('siguiente');
          break;
        case 'ArrowUp':
          e.preventDefault();
          navegarNoticias('anterior');
          break;
        case ' ':
          e.preventDefault();
          toggleLectura();
          break;
        case 'Enter':
          e.preventDefault();
          abrirNoticia();
          break;
        case 'h':
        case 'H':
          e.preventDefault();
          leerBienvenida();
          break;
        case 'm':
        case 'M':
          e.preventDefault();
          speechSynthesis.cancel();
          leerTexto('Lectura detenida', true, true);
          break;
        case 'r':
        case 'R':
          e.preventDefault();
          repetirNoticia();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [noticiaActual, noticias]);

  const navegarNoticias = (direccion) => {
    setEstaLeyendo(false);
    let nuevaNoticia = noticiaActual;
    
    if (direccion === 'siguiente' && noticiaActual < noticias.length - 1) {
      nuevaNoticia = noticiaActual + 1;
    } else if (direccion === 'anterior' && noticiaActual > 0) {
      nuevaNoticia = noticiaActual - 1;
    } else {
      // Feedback cuando llegamos al límite
      const mensaje = direccion === 'siguiente' 
        ? 'Has llegado a la última noticia' 
        : 'Has llegado a la primera noticia';
      leerTexto(mensaje, true, true);
      return;
    }

    setNoticiaActual(nuevaNoticia);
    const mensaje = `Noticia ${nuevaNoticia + 1} de ${noticias.length}. ${noticias[nuevaNoticia].title}`;
    leerTexto(mensaje, true, true);
  };

  const repetirNoticia = () => {
    const noticia = noticias[noticiaActual];
    if (noticia) {
      const texto = `Repitiendo noticia ${noticiaActual + 1} de ${noticias.length}. ${noticia.title}. ${noticia.description || ''}`;
      leerTexto(texto, true, true);
    }
  };

  // Mejora: Manejo del foco automático
  useEffect(() => {
    if (noticiaRefs.current[noticiaActual]) {
      noticiaRefs.current[noticiaActual].focus();
      noticiaRefs.current[noticiaActual].scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [noticiaActual]);

  const toggleLectura = () => {
    setEstaLeyendo(!estaLeyendo);
    const noticia = noticias[noticiaActual];
    if (!estaLeyendo && noticia) {
      const texto = `${noticia.title}. ${noticia.description || ''}`;
      leerTexto(texto, true, true);
    } else {
      speechSynthesis.cancel();
      leerTexto('Lectura pausada', true, true);
    }
  };

  const abrirNoticia = () => {
    const noticia = noticias[noticiaActual];
    if (noticia && noticia.url) {
      window.open(noticia.url, '_blank');
      leerTexto('Abriendo noticia en una nueva ventana. Puedes volver a esta página con Alt + Tab.');
    }
  };

  return (
    <main className="noticias-container" role="main">
      <h1 tabIndex="0">Lector de Noticias Accesible</h1>
      
      {error && (
        <div className="error-container" role="alert" aria-live="assertive">
          <p className="error">{error}</p>
        </div>
      )}
      
      <div 
        ref={instruccionesRef}
        className="instrucciones" 
        role="region" 
        aria-label="Instrucciones de navegación"
        tabIndex="0"
      >
        <h2>Instrucciones de Navegación</h2>
        <ul>
          <li>Flechas ↑↓: Navegar entre noticias</li>
          <li>ESPACIO: Leer/pausar noticia actual</li>
          <li>ENTER: Abrir enlace de la noticia</li>
          <li>H: Escuchar instrucciones</li>
          <li>M: Silenciar todas las lecturas</li>
          <li>R: Repetir última noticia</li>
        </ul>
        <p>Total de noticias disponibles: {noticias.length}</p>
      </div>

      <div role="status" aria-live="polite" className="sr-only">
        {noticias.length > 0 && `${noticias.length} noticias cargadas`}
      </div>

      {noticias.length > 0 ? (
        <section 
          role="feed" 
          aria-label="Lista de noticias"
          className="noticias-lista"
        >
          {noticias.map((article, index) => (
            <article
              key={index}
              ref={el => noticiaRefs.current[index] = el}
              className={`noticia ${index === noticiaActual ? 'noticia-activa' : ''}`}
              role="article"
              aria-selected={index === noticiaActual}
              tabIndex={index === noticiaActual ? 0 : -1}
              aria-label={`Noticia ${index + 1} de ${noticias.length}`}
            >
              {article.urlToImage && (
                <img 
                  src={article.urlToImage} 
                  alt={article.title}
                  className="noticia-img"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.alt = 'Error al cargar la imagen';
                  }}
                />
              )}
              <h2>{article.title}</h2>
              <p>{article.description}</p>
              <div className="noticia-meta">
                <p className="noticia-fecha">
                  {new Date(article.publishedAt).toLocaleDateString('es-ES')}
                </p>
                <a 
                  href={article.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="noticia-enlace"
                  aria-label={`Leer más sobre: ${article.title}`}
                >
                  Leer artículo completo
                </a>
              </div>
            </article>
          ))}
        </section>
      ) : (
        <p role="status" aria-live="polite">Cargando noticias...</p>
      )}
    </main>
  );
};

export default Noticias;